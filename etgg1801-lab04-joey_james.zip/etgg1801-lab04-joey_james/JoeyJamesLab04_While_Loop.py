# ETGG1801-90
# Joey James
# Lab 4 Flow Control
# 9/24/2020

import time  # for later

print("\n\n\nWelcome to FizzBuzz 1 to 100. If the number is divisible by 3, it's Fizz. If the number is divisible by "
      ""
      "5, it's "
      "Buzz, if it's both... it's FizzBuzz.")
time.sleep(10)
print("Ready?")
time.sleep(3)
print("GO!")
time.sleep(3)

i = 0
max_number = 100  # both for fizzbuzz loop

while i <= max_number:  # fizzbuzz loop
    time.sleep(.25)  # gives the program some realism, makes it look like it's actually counting out loud
    if (i % 3 == 0) and (i % 5 == 0):
        print("FizzBuzz")
    elif i % 3 == 0:
        print("Fizz")
    elif i % 5 == 0:
        print("Buzz")
    else:
        print(i)

    i += 1  # so loop will count up by one each run through

input("Press Enter to continue...")
# pause program

# extra stuff

MathProblem = True  # condition for new loop

while MathProblem:  # math problem game & loop
    x = int(input("What is 58 * 624?:"))
    if x == 36192:
        print("Good Job! (if you didn't use a calculator...)")
        MathProblem = False  # correct answer so condition changes to end loop
    else:
        print("WRONG ANSWER. TRY AGAIN.")

FunnyNumberGuess = True  # condition for second loop and game

while FunnyNumberGuess:
    x = int(input("I'm thinking of a funny number, what is it?:"))
    if x == 789:
        print("Good Job! You win.")
        time.sleep(3)
        FunnyNumberGuess = False  # condition changes for correct answer to end loop
    elif x == 69:  # easter egg answers
        print("Really?...")
        time.sleep(3)
        print("wrong answer")
        time.sleep(2)
    elif x == 420:
        print("Blaze it... ")
        time.sleep(3)
        print("wrong answer though")
        time.sleep(2)
    elif x == 666:
        print("AHHHHHHHHHHHHHHHHHHHHHHHHH")
        time.sleep(1)
        print(".")
        time.sleep(1)
        print(".")
        time.sleep(1)
        print(".")
        time.sleep(3)
        print("You thought I died, didn't you? Nope. Wrong answer though, try again.")
        time.sleep(2)
    elif x == 115:
        print("**Heavy Metal Music Sounds in the distance**")
        time.sleep(3)
        print("Try again")
        time.sleep(2)
    else:
        print("WRONG ANSWER. TRY AGAIN.")  # not right answer, also not easter egg, loop continues
        time.sleep(.5)
