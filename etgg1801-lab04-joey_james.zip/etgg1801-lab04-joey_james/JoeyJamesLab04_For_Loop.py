# ETGG1801-90
# Joey James
# Lab 4
# 9/24/2020

import pygame
import time
import random

win_width = 1000
win_height = 1000
window = pygame.display.set_mode((win_width, win_height))  # set up window

myColors = [(255, 0, 0), (255, 128, 0), (255, 255, 0), (128, 255, 0), (0, 255, 0), (0, 255, 128), (0, 255, 255),
            (0, 128, 255), (0, 0, 255), (127, 0, 255), (255, 0, 255), (255, 0, 127), (128, 128, 128), (255, 255, 255),
            (102, 51, 0), (0, 0, 0)]  # put in all saturated colors from color wheel

count = 1
for count in range(0, 101):  # for loop to draw circles
    x = random.randint(0, win_width)
    y = random.randint(0, win_height)
    z = random.randint(3, 150)  # added random integer to the radius of the circles
    pygame.draw.circle(window, random.choice(myColors), (x, y), z)
    time.sleep(.10)  # added time to see the drawings as they happen
    pygame.display.update()  # to actually make this ^^^ possible visibly

time.sleep(5)  # halting program for 5 secs

pygame.quit()  # quitting the program properly
