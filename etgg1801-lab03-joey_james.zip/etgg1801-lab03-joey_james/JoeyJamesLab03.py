# ETGG1801.90
# Joey James
# Lab 03 Modules
# 9/20/2020

import pygame
import time
import random

# setting up window
win_width = 1000
win_height = 1000

window = pygame.display.set_mode((win_width, win_height))

# all the random colors I'm gonna need, some different objects need the same variables to make the picture work
r_color1 = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
r_color2 = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
r_color3 = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
r_color4 = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
r_color5 = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
r_color6 = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
r_color7 = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

# polygon coordinates for the mountains in my picture
mtn1 = ((700, 100), (900, 1000), (500, 1000))
mtn2 = ((200, 300), (350, 1000), (50, 1000))
mtn3 = ((100, 500), (0, 1000), (350, 1000))
mtn4 = ((25, 650), (-100, 1000), (250, 1000))
mtn5 = ((950, 575), (700, 1000), (1100, 1000))

# the background, a.k.a. the sky
pygame.draw.rect(window, r_color2, (0, 0, 1000, 1000))

# The stars, 1000, random in location & size
i = 0
star_amount = 1000
while i < star_amount:
    random_star_coordinate = random.randint(0, 1000)
    star_size = random.randint(2, 4)
    star_x = random.randint(0, win_width)
    star_y = random.randint(0, win_height)
    pygame.draw.circle(window, r_color4, (star_x, star_y), star_size)

    i += 1

# The moon, mountains, and foreground
pygame.draw.circle(window, r_color3, (875, 150), 100)
pygame.draw.polygon(window, r_color7, mtn4)
pygame.draw.polygon(window, r_color7, mtn5)
pygame.draw.polygon(window, r_color1, mtn1)
pygame.draw.polygon(window, r_color1, mtn2)
pygame.draw.polygon(window, r_color1, mtn3)
pygame.draw.circle(window, r_color5, (1100, 5000), 4200)
pygame.draw.circle(window, r_color6, (-300, 4900), 4100)
# The finished product kinda looks like a Dune book cover

# showing the picture in correct order
pygame.display.update()

# seconds until the program shuts down
time.sleep(10)

# exiting the program properly
pygame.quit()
