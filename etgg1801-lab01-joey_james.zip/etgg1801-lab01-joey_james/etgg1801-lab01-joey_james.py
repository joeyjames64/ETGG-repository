# ETGG1801-90
# Joey
# James
# Lab 1: Hello World
# 9/3/2020
from math import sqrt

firstName = "Joey"
lastName = "James"
opposite = 2.3
adjacent = 8
print("Lab01 created by: " + firstName + " " + lastName)
print(firstName, end=' ')
print(lastName)
hypotenuse = sqrt(opposite ** 2) + sqrt(adjacent ** 2)
print("The hypotenuse length is " + str(hypotenuse) + " if the other sides are " + str(opposite) + " and " + str(
    adjacent))
input("Press Enter to continue...")
print("Oh, good, you pressed Enter. I'm glad you followed instructions")
print("Now that you're here, enter your name:")
user_name = input()
print("Hello, " + user_name + ".", end=' ')
print("If you can answer this question correctly, you win and the program will be complete.")
input("Press Enter to continue...")
print(
    'What happens when Pinocchio says "my nose will now grow"?')
input("your answer: ")
print(
    "Trick question, " + user_name + ", the program continued because there isn't a correct answer to that question; "
                                     "it's a paradox.",
    end=" ")  # this was a way of making the program seem like it was doing something cool without actually doing it
# because I'm unsure how to make the input be specific yet.
print("Press enter one more time and the program will close")
input("Press Enter to continue...")
