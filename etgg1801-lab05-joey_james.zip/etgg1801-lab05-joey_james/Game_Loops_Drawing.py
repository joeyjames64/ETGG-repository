# ETGG1801.90
# Joey James
# Lab 5 Game Labs
# 10/10/2020

import pygame
# initiate pygame
pygame.init()

# general variables
isRunning = True
myGameClock = pygame.time.Clock()

# background screen
window_w = 800
window_h = 600
myGameWindow = pygame.display.set_mode((window_w, window_h))

# Canvas
notCanvas_area = 200
gap = 12
myCanvas = pygame.Surface((window_w - gap * 2, window_h - notCanvas_area))

# Color gradient values
redValue = 255
greenValue = 0
blueValue = 0

# Mouse values
mouse_area_width = 400
mouse_area_height = 300

# Color selection values
colorSelection_width = 500
colorSelectionIndividual_height = 40
colorSelection_yAxis = window_h - notCanvas_area + gap * 4

# Main game-loop
while isRunning:

    myGameEvents = pygame.event.get()
    mousePosition = pygame.mouse.get_pos()
    # putting canvas over window
    myGameWindow.blit(myCanvas, (0, 0))
    # giving mouse buttons functionality
    left_mouse, right_mouse, middle_mouse = pygame.mouse.get_pressed()
    # giving the mouse a 2D height and width for detection
    mouse_area_width, mouse_area_height = pygame.mouse.get_pos()
    # for loop to trigger events
    for event in myGameEvents:
        if event.type == pygame.QUIT:
            isRunning = False
            break
        # Giving the left mouse button purpose
        if left_mouse:
            # Finding mouse input for picking colors
            if gap < mouse_area_width < gap + colorSelection_width:

                percentage = (mouse_area_width - gap) / colorSelection_width
                colorValue = int(255 * percentage)
                if colorSelection_yAxis < mouse_area_height < colorSelection_yAxis + colorSelectionIndividual_height:
                    redValue = colorValue
                elif colorSelection_yAxis + colorSelectionIndividual_height < mouse_area_height < colorSelection_yAxis +\
                        colorSelectionIndividual_height * 2:
                            greenValue = colorValue
                elif colorSelection_yAxis + colorSelectionIndividual_height * 2 < mouse_area_height < \
                        colorSelection_yAxis + colorSelectionIndividual_height * 3:
                            blueValue = colorValue
            # Drawing whatever color is picked with a circle
            pygame.draw.circle(myCanvas, (redValue, greenValue, blueValue), mousePosition, 30, 0)
        # Giving key presses functionality
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DELETE:
                myCanvas.fill((0, 0, 0))
            elif event.key == pygame.K_BACKSPACE:
                myCanvas.fill((0, 0, 0))
            elif event.key == pygame.K_x:
                isRunning = False
                break
            elif event.key == pygame.K_ESCAPE:
                isRunning = False
                break

    # Surfaces for picking color and creating gradients
    lineX_position = gap
    while lineX_position < gap + colorSelection_width:
        percentage = (lineX_position - gap) / colorSelection_width
        colorValue = int(percentage * 255)
        pygame.draw.line(myGameWindow, (colorValue, 0, 0), (lineX_position, colorSelection_yAxis), (lineX_position, colorSelection_yAxis + colorSelectionIndividual_height))
        pygame.draw.line(myGameWindow, (0, colorValue, 0), (lineX_position, colorSelection_yAxis + colorSelectionIndividual_height),
                         (lineX_position, colorSelection_yAxis + colorSelectionIndividual_height * 2))
        pygame.draw.line(myGameWindow, (0, 0, colorValue), (lineX_position, colorSelection_yAxis + colorSelectionIndividual_height * 2),
                         (lineX_position, colorSelection_yAxis + colorSelectionIndividual_height * 3))
        lineX_position += 1

    # Current color selected \/
    pygame.draw.circle(myGameWindow, (redValue, greenValue, blueValue), (700, 505), 60)

    pygame.display.update()

pygame.quit()
