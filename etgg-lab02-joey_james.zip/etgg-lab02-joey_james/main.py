#ETGG1801.90
#Joey James
#Lab 2 Expressions
#9/13/2020

#\/ \/ \/ Me having fun and modifying the lab a bit
playerName = str(input("Enter your name: "))

#ASCII picture 1 head
print("\n\n\n\t\t^^^")
print("\t   ^___^")
print("\t </     \\>")
print("\t | 0   0 |")
print("\t{|  ' '  |}")
print("\t |       |")
print("\t  \\ === /")
print("\t   |\\_/|")
print("\t   |___|")

#ASCII picture 2 body
print("\t###\\   /###\n # #####\\ /##### # \n## ######|###### ##\n## ######|###### ##\n## ######|###### ##"
      "\n## ######|###### ##\n## ######|###### ##\n## ######|###### ##\n() ######|###### ()\n"
      "   _____________ \n\n\n")


print("This ^^^ is you " + playerName + "!")

#Interactive Health Bar
#Structure
barLength = int(input("Enter the length of " + playerName + "'s Health Bar (Something between 16 and 100): "))

#Inside the Bar
currentHealth = int(input("Enter Current Health of " + playerName + " (any number): "))
maxHealth = int(input("Enter Maximum Health of " + playerName + " (any number bigger than Current Health value): "))

#calculations i need to make the bar work
percentage = currentHealth / maxHealth
heartAmount = int(percentage * barLength)
blankAmount = int(barLength - heartAmount)

#Making the actual physical bar... IN ONE PRINT STATEMENT!!!     AKA headache material
print("\n\n\n" + playerName.upper() + "'S HEALTH BAR:" + "\n" + "/" + ("-" * barLength) + "\\""\n""|" + ("@" * heartAmount) + (blankAmount * " " + "|") + '\n' +
"\\" + ("-" * barLength) + "/")

#Pausing Program
input("Press Enter to continue...")